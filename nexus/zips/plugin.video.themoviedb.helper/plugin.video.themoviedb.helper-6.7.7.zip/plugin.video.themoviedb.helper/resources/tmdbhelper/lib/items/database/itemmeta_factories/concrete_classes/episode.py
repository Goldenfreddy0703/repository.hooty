from tmdbhelper.lib.items.database.itemmeta_factories.concrete_classes.basemedia import MediaItem
from tmdbhelper.lib.addon.tmdate import is_future_timestamp


class Episode(MediaItem):
    infolabels_dbcitem_routes = (
        (('certification', None), 'name', 'mpaa'),
        (('video', None), 'path', 'trailer'),
        (('playcount', None), 'plays', 'playcount'),
    )

    art_dbclist_routes = (
        *MediaItem.art_dbclist_routes,
        (('art_poster', 'season'), 'poster'),
        (('art_fanart', 'season'), 'fanart'),
        (('art_clearlogo', 'season'), 'clearlogo'),
        (('art_landscape', 'season'), 'landscape'),
        (('art_poster', 'tvshow'), 'poster'),
        (('art_fanart', 'tvshow'), 'fanart'),
        (('art_landscape', 'tvshow'), 'landscape'),
        (('art_clearlogo', 'tvshow'), 'clearlogo'),
        (('art_extrafanart', 'tvshow'), 'fanart'),
        (('fanart_tv_poster', 'season'), 'poster'),
        (('fanart_tv_fanart', 'season'), 'fanart'),
        (('fanart_tv_landscape', 'season'), 'landscape'),
        (('fanart_tv_banner', 'season'), 'banner'),
        (('fanart_tv_poster', 'tvshow'), 'poster'),
        (('fanart_tv_fanart', 'tvshow'), 'fanart'),
        (('fanart_tv_landscape', 'tvshow'), 'landscape'),
        (('fanart_tv_clearlogo', 'tvshow'), 'clearlogo'),
        (('fanart_tv_clearart', 'tvshow'), 'clearart'),
        (('fanart_tv_banner', 'tvshow'), 'banner'),
    )

    infoproperties_dbclist_routes = (
        *MediaItem.infoproperties_dbclist_routes,
        {
            'instance': ('studio', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id', 'logo': 'logo', 'country': 'country'},
            'propname': ('network', ),  # For backwards compatibility also set studio to network
            'joinings': None
        }
    )

    def get_premiered_status(self):
        premiered = self.get_data_value('premiered')
        if not premiered:
            return 'Unknown'
        if is_future_timestamp(premiered, "%Y-%m-%d", 10, use_today=True, days=1):
            return 'Anticipated'
        if is_future_timestamp(premiered, "%Y-%m-%d", 10, use_today=True, days=0):
            return 'Airing'
        return 'Released'

    def get_infolabels_special(self, infolabels):
        infolabels['status'] = self.get_premiered_status()
        return infolabels

    def get_unique_ids(self, unique_ids):
        unique_ids = super().get_unique_ids(unique_ids)
        for i in self.parent_db_cache.return_basemeta_db('unique_id', 'season').cached_data:
            unique_ids[f"season.{i['key']}"] = i['value']
        for i in self.parent_db_cache.return_basemeta_db('unique_id', 'tvshow').cached_data:
            unique_ids[f"tvshow.{i['key']}"] = i['value']
        unique_ids['tmdb'] = unique_ids['tvshow.tmdb'] = self.parent_db_cache.tmdb_id
        return unique_ids

    def get_infoproperties_custom(self, infoproperties):
        infoproperties = super().get_infoproperties_custom(infoproperties)
        for i in self.parent_db_cache.return_basemeta_db('custom', 'tvshow').cached_data:
            infoproperties[f"tvshow.{i['key']}"] = i['value']
        for i in self.parent_db_cache.return_basemeta_db('custom', 'season').cached_data:
            infoproperties[f"season.{i['key']}"] = i['value']
        return infoproperties

    def get_infoproperties_episode_type(self, infoproperties):
        infoproperties['episode_type'] = self.get_data_value('status')
        return infoproperties

    def get_infoproperties_special(self, infoproperties):
        infoproperties = self.get_infoproperties_custom(infoproperties)
        infoproperties = self.get_infoproperties_episode_type(infoproperties)
        infoproperties = self.get_infoproperties_progress(infoproperties)
        return infoproperties
