from ytmusicapi._version import __version__
from ytmusicapi.ytmusic import YTMusic

__copyright__ = 'Copyright 2020 sigma67'
__license__ = 'MIT'
__title__ = 'ytmusicapi'
