YTM_DOMAIN = 'https://music.youtube.com'
YTM_BASE_API = YTM_DOMAIN + '/youtubei/v1/'
YTM_PARAMS = '?alt=json&key=AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/20100101 Firefox/88.0'
