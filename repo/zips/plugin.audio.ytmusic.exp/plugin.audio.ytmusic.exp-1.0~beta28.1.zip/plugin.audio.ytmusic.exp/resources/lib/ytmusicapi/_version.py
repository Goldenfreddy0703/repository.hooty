__version__ = "1.6.0 plus various commits"
