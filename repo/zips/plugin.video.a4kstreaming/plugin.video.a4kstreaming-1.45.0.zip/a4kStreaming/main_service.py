# -*- coding: utf-8 -*-

from a4kStreaming import api, service

if __name__ == '__main__':
    service.start(api.A4kStreamingApi())
